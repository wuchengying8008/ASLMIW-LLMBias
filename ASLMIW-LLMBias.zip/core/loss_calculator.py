"""
Loss Calculation Module
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any
from utils.logger import setup_logger
from config.settings import Config


class LossCalculator:
    """Loss Calculator"""

    def __init__(self):
        self.logger = setup_logger("LossCalculator")
        self.precision_threshold = Config.PRECISION_THRESHOLD

        # Define different loss functions
        self.mse_loss = nn.MSELoss()
        self.mae_loss = nn.L1Loss()
        self.huber_loss = nn.SmoothL1Loss()

    def calculate_task_loss(self,
                            predictions: torch.Tensor,
                            targets: torch.Tensor,
                            precision: float,
                            group_id: int,
                            scenario_id: int,
                            task_type: str = "regression") -> torch.Tensor:
        """
        Calculate task loss (Equations 15a, 15b)

        Args:
            predictions: Predicted values
            targets: Ground truth values
            precision: Prediction precision
            group_id: Group ID
            scenario_id: Scenario ID
            task_type: Task type

        Returns:
            Loss value
        """
        # Equation 15a: Check precision threshold
        if precision < self.precision_threshold:
            self.logger.warning(
                f"Group {group_id} in scenario {scenario_id} has precision {precision:.4f} "
                f"below threshold {self.precision_threshold}"
            )
            return torch.tensor(0.0, device=predictions.device)

        # Select loss function based on task type
        if task_type == "regression":
            base_loss = self.mse_loss(predictions, targets)
        elif task_type == "classification":
            base_loss = self._classification_loss(predictions, targets)
        else:
            base_loss = self.mse_loss(predictions, targets)

        # Equation 15b: Calculate custom loss
        custom_loss = self._apply_custom_factors(base_loss, precision, group_id, scenario_id)

        return custom_loss

    def _classification_loss(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Classification task loss"""
        if predictions.shape == targets.shape:
            # If it's probability prediction
            return self.mse_loss(predictions, targets)
        else:
            # If it's class prediction
            cross_entropy = nn.CrossEntropyLoss()
            return cross_entropy(predictions, targets)

    def _apply_custom_factors(self, base_loss: torch.Tensor,
                              precision: float,
                              group_id: int,
                              scenario_id: int) -> torch.Tensor:
        """Apply custom factors"""
        # Precision-based weight
        precision_weight = 1 + 0.1 * precision

        # Group-based weight (special groups may have different weights)
        group_weight = self._get_group_weight(group_id)

        # Scenario-based weight
        scenario_weight = self._get_scenario_weight(scenario_id)

        # Combine weights
        total_weight = precision_weight * group_weight * scenario_weight

        custom_loss = base_loss * total_weight

        self.logger.debug(
            f"Loss calculation: Base loss={base_loss.item():.4f}, "
            f"Precision weight={precision_weight:.2f}, "
            f"Group weight={group_weight:.2f}, "
            f"Scenario weight={scenario_weight:.2f}, "
            f"Final loss={custom_loss.item():.4f}"
        )

        return custom_loss

    def _get_group_weight(self, group_id: int) -> float:
        """Get group weight"""
        group_weights = {
            1: 1.0,  # Conservative investors - standard weight
            2: 1.0,  # Moderate investors - standard weight
            3: 1.1,  # Aggressive investors - slightly higher weight
            4: 1.2,  # Professional investors - higher weight
            5: 1.5  # Special groups - highest weight
        }
        return group_weights.get(group_id, 1.0)

    def _get_scenario_weight(self, scenario_id: int) -> float:
        """Get scenario weight"""
        scenario_weights = {
            0: 1.0,  # Wealth management - standard weight
            1: 1.2,  # Risk assessment - higher weight
            2: 1.1,  # Portfolio optimization - slightly higher weight
            3: 1.0,  # Retirement planning - standard weight
            4: 1.3  # Tax optimization - high weight
        }
        return scenario_weights.get(scenario_id, 1.0)

    def calculate_aggregate_loss(self, task_losses: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        Calculate aggregate loss

        Args:
            task_losses: Task loss dictionary

        Returns:
            Aggregate loss value
        """
        if not task_losses:
            return torch.tensor(0.0)

        # Average all task losses
        total_loss = sum(task_losses.values()) / len(task_losses)

        self.logger.info(
            f"Aggregate loss calculation completed, number of tasks: {len(task_losses)}, total loss: {total_loss.item():.4f}")

        return total_loss

    def validate_predictions(self,
                             predictions: torch.Tensor,
                             targets: torch.Tensor,
                             threshold: float = None) -> Dict[str, float]:
        """
        Validate prediction results

        Args:
            predictions: Predicted values
            targets: Ground truth values
            threshold: Precision threshold

        Returns:
            Validation metrics dictionary
        """
        if threshold is None:
            threshold = self.precision_threshold

        metrics = {}

        # Calculate various metrics
        metrics['mse'] = self.mse_loss(predictions, targets).item()
        metrics['mae'] = self.mae_loss(predictions, targets).item()
        metrics['huber'] = self.huber_loss(predictions, targets).item()

        # Calculate precision (simplified version)
        if predictions.shape == targets.shape:
            abs_errors = torch.abs(predictions - targets)
            relative_errors = abs_errors / (torch.abs(targets) + 1e-8)
            metrics['precision'] = 1.0 - torch.mean(relative_errors).item()
        else:
            metrics['precision'] = 0.0

        metrics['meets_threshold'] = metrics['precision'] >= threshold

        return metrics