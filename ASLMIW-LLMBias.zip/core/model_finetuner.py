"""
模型微调模块 - 实现LLM的偏见优化微调
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup
from typing import Dict, List, Any, Optional
from utils.logger import setup_logger
from config.settings import Config

class BiasAwareDataset(Dataset):
    """偏见感知数据集"""
    
    def __init__(self, finetuning_data: Dict[str, Any]):
        self.input_ids = finetuning_data['input_ids']
        self.attention_mask = finetuning_data['attention_mask'] 
        self.labels = finetuning_data['labels']
        self.bias_scores = finetuning_data['bias_scores']
        self.metadata = finetuning_data['metadata']
    
    def __len__(self):
        return len(self.input_ids)
    
    def __getitem__(self, idx):
        return {
            'input_ids': self.input_ids[idx],
            'attention_mask': self.attention_mask[idx],
            'labels': self.labels[idx],
            'bias_score': torch.tensor(self.bias_scores[idx], dtype=torch.float),
            'metadata': self.metadata[idx]
        }

class ModelFinetuner:
    """模型微调器"""
    
    def __init__(self, model_name: str = Config.MODEL_NAME):
        self.logger = setup_logger("ModelFinetuner")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 初始化模型和分词器
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)
        
        self.optimizer = None
        self.scheduler = None
        
        self.logger.info(f"模型微调器初始化完成")
    
    def setup_training(self, training_data: Dict[str, Any], learning_rate: float = Config.LEARNING_RATE):
        """设置训练参数"""
        self.dataset = BiasAwareDataset(training_data)
        self.dataloader = DataLoader(
            self.dataset, 
            batch_size=Config.BATCH_SIZE, 
            shuffle=True,
            num_workers=2
        )
        
        # 优化器
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=0.01
        )
        
        # 学习率调度器
        self.scheduler = get_linear_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=Config.WARMUP_STEPS,
            num_training_steps=len(self.dataloader) * Config.NUM_EPOCHS
        )
        
        self.logger.info("训练参数设置完成")
    
    def debiasing_finetune(self, num_epochs: int = Config.NUM_EPOCHS) -> Dict[str, List[float]]:
        """
        去偏见微调
        
        Args:
            num_epochs: 训练轮数
            
        Returns:
            训练历史记录
        """
        self.logger.info(f"开始去偏见微调，共{num_epochs}个周期")
        
        training_history = {
            'losses': [],
            'bias_scores': [],
            'perplexities': []
        }
        
        self.model.train()
        
        for epoch in range(num_epochs):
            epoch_loss = 0.0
            epoch_bias_score = 0.0
            
            for batch_idx, batch in enumerate(self.dataloader):
                # 移动到设备
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                bias_scores = batch['bias_score'].to(self.device)
                
                # 前向传播
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                
                # 偏见感知损失调整
                debiased_loss = self._apply_bias_aware_loss(loss, bias_scores, outputs.logits, labels)
                
                # 反向传播
                self.optimizer.zero_grad()
                debiased_loss.backward()
                
                # 梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), Config.MAX_GRAD_NORM)
                
                self.optimizer.step()
                self.scheduler.step()
                
                epoch_loss += debiased_loss.item()
                epoch_bias_score += bias_scores.mean().item()
                
                if batch_idx % 10 == 0:
                    self.logger.info(f"Epoch {epoch+1}, Batch {batch_idx}, Loss: {debiased_loss.item():.4f}")
            
            # 计算周期统计
            avg_loss = epoch_loss / len(self.dataloader)
            avg_bias = epoch_bias_score / len(self.dataloader)
            perplexity = torch.exp(torch.tensor(avg_loss)).item()
            
            training_history['losses'].append(avg_loss)
            training_history['bias_scores'].append(avg_bias)
            training_history['perplexities'].append(perplexity)
            
            self.logger.info(
                f"Epoch {epoch+1} 完成: "
                f"Loss: {avg_loss:.4f}, "
                f"Avg Bias: {avg_bias:.4f}, "
                f"Perplexity: {perplexity:.4f}"
            )
        
        self.logger.info("去偏见微调完成")
        return training_history
    
    def _apply_bias_aware_loss(self, base_loss: torch.Tensor, bias_scores: torch.Tensor,
                             logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """
        应用偏见感知损失调整
        
        Args:
            base_loss: 基础语言模型损失
            bias_scores: 偏见分数
            logits: 模型输出
            labels: 目标标签
            
        Returns:
            调整后的损失
        """
        # 高偏见样本给予更高权重
        bias_weights = 1.0 + bias_scores
        
        # 计算加权损失
        weighted_loss = base_loss * bias_weights.mean()
        
        # 添加多样性正则化（减少刻板输出）
        diversity_penalty = self._calculate_diversity_penalty(logits)
        
        # 最终损失
        final_loss = weighted_loss + 0.1 * diversity_penalty
        
        return final_loss
    
    def _calculate_diversity_penalty(self, logits: torch.Tensor) -> torch.Tensor:
        """计算多样性惩罚（减少重复刻板模式）"""
        # 计算token分布的熵（鼓励多样性）
        probs = torch.softmax(logits, dim=-1)
        entropy = -torch.sum(probs * torch.log(probs + 1e-8), dim=-1)
        
        # 我们希望有适度的熵（既不太确定也不太不确定）
        target_entropy = 2.0  # 目标熵值
        entropy_penalty = torch.abs(entropy.mean() - target_entropy)
        
        return entropy_penalty
    
    def generate_debiased_response(self, prompt: str, max_length: int = 200) -> str:
        """生成去偏见回复"""
        self.model.eval()
        
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                inputs.input_ids,
                max_length=max_length,
                num_return_sequences=1,
                temperature=0.8,  # 适度随机性
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                repetition_penalty=1.2  # 减少重复
            )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        # 移除提示词部分，只返回生成的回复
        response = response[len(prompt):].strip()
        
        return response
    
    def save_model(self, save_path: str):
        """保存微调后的模型"""
        self.model.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        self.logger.info(f"模型保存到: {save_path}")
    
    def load_model(self, load_path: str):
        """加载微调后的模型"""
        self.model = AutoModelForCausalLM.from_pretrained(load_path).to(self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(load_path)
        self.logger.info(f"模型从 {load_path} 加载")