"""
Perturbation Learning Module - Implements Dynamic Feature Perturbation
"""

import pandas as pd
import numpy as np
import random
from typing import List, Dict, Any
from utils.logger import setup_logger
from config.settings import DYNAMIC_FEATURES


class PerturbationLearner:
    """Perturbation Learner"""

    def __init__(self):
        self.logger = setup_logger("PerturbationLearner")
        self.dynamic_features = DYNAMIC_FEATURES

    def apply_perturbation(self, samples: pd.DataFrame, dynamic_features: List[str] = None) -> pd.DataFrame:
        """
        Apply perturbation learning (Equations 10, 11)

        Args:
            samples: Input samples
            dynamic_features: List of dynamic features

        Returns:
            Perturbed samples
        """
        self.logger.info("Starting perturbation learning")

        if dynamic_features is None:
            dynamic_features = self.dynamic_features

        perturbed_samples = samples.copy()

        for feature in dynamic_features:
            if feature in perturbed_samples.columns and perturbed_samples[feature].dtype in [np.int64, np.float64]:
                # Equation 10: Dynamic feature perturbation
                perturbed_samples = self._perturb_feature(perturbed_samples, feature)

        # Equation 11: Re-update sample data
        final_samples = self._reupdate_samples(perturbed_samples)

        self.logger.info(f"Perturbation learning completed, processed {len(final_samples)} samples")
        return final_samples

    def _perturb_feature(self, samples: pd.DataFrame, feature: str) -> pd.DataFrame:
        """Apply perturbation to a single feature"""
        feature_values = samples[feature]

        # Calculate feature bounds
        lower_bound = feature_values.min()
        upper_bound = feature_values.max()

        # Generate random perturbation factors
        random_factors = np.random.uniform(0.8, 1.2, len(samples))

        # Generate market reaction features
        market_reaction = np.random.uniform(lower_bound * 0.1, upper_bound * 0.1, len(samples))

        # Apply perturbation formula
        perturbed_values = feature_values * random_factors + market_reaction

        # Ensure values are within reasonable range
        if lower_bound != upper_bound:  # Avoid division by zero
            perturbed_values = np.clip(perturbed_values, lower_bound * 0.5, upper_bound * 1.5)

        samples[feature] = perturbed_values

        self.logger.debug(f"Feature {feature} perturbation applied")
        return samples

    def _reupdate_samples(self, samples: pd.DataFrame) -> pd.DataFrame:
        """Re-update sample data (Equation 11)"""
        # More complex sample update logic can be implemented here
        # For example, feature adjustments based on business rules

        updated_samples = samples.copy()

        # Example: Ensure investment amount to income ratio is reasonable
        if 'investment_amount' in updated_samples.columns and 'annual_income' in updated_samples.columns:
            # Investment amount should not exceed 50% of annual income
            max_investment = updated_samples['annual_income'] * 0.5
            updated_samples['investment_amount'] = np.minimum(
                updated_samples['investment_amount'],
                max_investment
            )

        # Example: Association between risk tolerance and investment experience
        if 'risk_tolerance' in updated_samples.columns and 'investment_experience' in updated_samples.columns:
            # Experienced investors may have higher risk tolerance
            experience_bonus = updated_samples['investment_experience'] * 0.01
            if updated_samples['risk_tolerance'].dtype == object:
                # Simplified handling for categorical variables
                pass

        return updated_samples

    def synthesize_new_samples(self, original_samples: pd.DataFrame, num_new_samples: int = None) -> pd.DataFrame:
        """
        Synthesize new samples (Equations 12, 13)

        Args:
            original_samples: Original samples
            num_new_samples: Number of new samples to generate

        Returns:
            Complete dataset including new samples
        """
        if num_new_samples is None:
            num_new_samples = len(original_samples) // 2

        self.logger.info(f"Starting synthesis of {num_new_samples} new samples")

        numeric_data = original_samples.select_dtypes(include=[np.number])
        if numeric_data.empty:
            self.logger.warning("No numeric data available for synthesis")
            return original_samples

        # Use K-means clustering
        n_clusters = min(3, len(numeric_data))
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        clusters = kmeans.fit_predict(numeric_data)

        original_samples = original_samples.copy()
        original_samples['cluster'] = clusters

        synthetic_samples = []

        for _ in range(num_new_samples):
            # Randomly select a cluster
            cluster_id = random.randint(0, n_clusters - 1)
            cluster_samples = original_samples[original_samples['cluster'] == cluster_id]

            if len(cluster_samples) >= 2:
                # Randomly select two samples from the cluster
                sample1, sample2 = cluster_samples.sample(2).iloc

                # Equation 12: Generate new sample through linear interpolation
                alpha = random.random()
                new_sample = self._interpolate_samples(sample1, sample2, alpha)
                synthetic_samples.append(new_sample)

        # Create synthetic samples DataFrame
        if synthetic_samples:
            synthetic_df = pd.DataFrame(synthetic_samples)
            # Remove temporary cluster column
            if 'cluster' in synthetic_df.columns:
                synthetic_df = synthetic_df.drop('cluster', axis=1)

            # Equation 13: Merge into minority class
            final_dataset = pd.concat([original_samples.drop('cluster', axis=1), synthetic_df], ignore_index=True)

            self.logger.info(f"Sample synthesis completed, total samples: {len(final_dataset)}")
            return final_dataset
        else:
            self.logger.warning("Failed to synthesize new samples")
            return original_samples.drop('cluster', axis=1)

    def _interpolate_samples(self, sample1: pd.Series, sample2: pd.Series, alpha: float) -> pd.Series:
        """Sample interpolation"""
        new_sample = sample1.copy()

        for col in new_sample.index:
            if col != 'cluster' and pd.api.types.is_numeric_dtype(new_sample[col]):
                new_sample[col] = sample1[col] * alpha + sample2[col] * (1 - alpha)
            elif col == 'investor_id':
                # Generate new investor ID
                new_sample[col] = f"SYN_{random.randint(1000, 9999)}"

        return new_sample