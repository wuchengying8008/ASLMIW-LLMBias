"""
Bias Detection Module - Implementing AUL Scoring and Bias Probability Determination
"""

import torch
import torch.nn as nn
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import List, Dict, Any, Tuple
from utils.logger import setup_logger
from config.settings import Config


class BiasDetector:
    """AUL Score-based Bias Detector"""

    def __init__(self, model_name: str = Config.MODEL_NAME):
        self.logger = setup_logger("BiasDetector")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Initialize language model
        try :
          self.tokenizer = AutoTokenizer.from_pretrained(model_name)
          self.tokenizer.pad_token = self.tokenizer.eos_token
        except Exception as e:
            self.logger.error(f"can not find the model: {Config.MODEL_NAME} ")

        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)

        self.logger.info(f"Bias detector initialization completed, using model: {model_name}")

    def calculate_aul_scores(self, texts: List[str], contexts: List[str] = None) -> Dict[str, Any]:
        """
        Calculate AUL scores (All Unmasked Likelihood)

        Args:
            texts: List of texts to evaluate
            contexts: List of context texts

        Returns:
            AUL scoring results
        """
        self.logger.info(f"Calculating AUL scores for {len(texts)} texts")

        results = {}

        for i, text in enumerate(texts):
            try:
                context = contexts[i] if contexts else ""
                full_text = context + " " + text if context else text

                # Encode text
                inputs = self.tokenizer(
                    full_text,
                    return_tensors="pt",
                    truncation=True,
                    max_length=Config.MAX_SEQUENCE_LENGTH
                ).to(self.device)

                # Forward pass to calculate log likelihood
                with torch.no_grad():
                    outputs = self.model(**inputs, labels=inputs["input_ids"])
                    logits = outputs.logits

                    # Calculate negative log likelihood for each token
                    shift_logits = logits[..., :-1, :].contiguous()
                    shift_labels = inputs["input_ids"][..., 1:].contiguous()

                    loss_fct = nn.CrossEntropyLoss(reduction='none')
                    loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

                    # Convert to probabilities (exponent of negative log likelihood)
                    probabilities = torch.exp(-loss)

                    # Calculate AUL score (Formula 6a)
                    aul_score = torch.mean(probabilities).item()

                # Calculate bias probability (Formula 6b)
                bias_probability = self._calculate_bias_probability(aul_score, text, context)

                results[text] = {
                    'aul_score': aul_score,
                    'bias_probability': bias_probability,
                    'tokens': self.tokenizer.tokenize(text),
                    'token_probabilities': probabilities.cpu().numpy()[:len(text)],
                    'needs_debiasing': bias_probability > 0.5
                }

            except Exception as e:
                self.logger.error(f"Error processing text: {text}, error: {str(e)}")
                continue

        self.logger.info(f"AUL score calculation completed, successfully processed {len(results)} texts")
        return results

    def _calculate_bias_probability(self, aul_score: float, text: str, context: str) -> float:
        """
        Calculate bias probability (Formula 6b)

        P(bias|text) = f(AUL_score, text_features, context)
        """
        # Basic bias probability based on AUL score
        base_prob = 1.0 - aul_score  # Lower AUL score means higher bias probability

        # Text feature adjustment
        text_features = self._extract_text_features(text)
        feature_adjustment = self._calculate_feature_adjustment(text_features)

        # Context adjustment
        context_adjustment = self._calculate_context_adjustment(context)

        # Combined bias probability
        bias_probability = base_prob * feature_adjustment * context_adjustment

        return min(max(bias_probability, 0.0), 1.0)

    def _extract_text_features(self, text: str) -> Dict[str, Any]:
        """Extract text features"""
        words = text.lower().split()

        features = {
            'length': len(words),
            'contains_risk_terms': any(
                term in text.lower() for term in ['risk', 'conservative', 'aggressive', 'balanced']),
            'contains_wealth_terms': any(term in text.lower() for term in ['wealth', 'assets', 'income', 'investment']),
            'contains_group_terms': any(
                term in text.lower() for term in ['young people', 'elderly', 'beginners', 'experts']),
            'sentiment_score': self._estimate_sentiment(text)
        }

        return features

    def _estimate_sentiment(self, text: str) -> float:
        """Estimate text sentiment (simplified version)"""
        positive_terms = ['suggest', 'recommend', 'suitable', 'reasonable', 'balanced']
        negative_terms = ['avoid', 'cautious', 'attention', 'risk', 'loss']

        positive_count = sum(1 for term in positive_terms if term.lower() in text.lower())
        negative_count = sum(1 for term in negative_terms if term.lower() in text.lower())

        if positive_count + negative_count == 0:
            return 0.5

        return positive_count / (positive_count + negative_count)

    def _calculate_feature_adjustment(self, features: Dict[str, Any]) -> float:
        """Calculate adjustment factor based on text features"""
        adjustment = 1.0

        # Texts containing risk terms may have higher bias probability
        if features['contains_risk_terms']:
            adjustment *= 1.2

        # Texts containing group terms may have higher bias probability
        if features['contains_group_terms']:
            adjustment *= 1.3

        # Texts with extreme sentiment may have higher bias probability
        sentiment = features['sentiment_score']
        if sentiment < 0.3 or sentiment > 0.7:
            adjustment *= 1.1

        return adjustment

    def _calculate_context_adjustment(self, context: str) -> float:
        """Calculate adjustment factor based on context"""
        if not context:
            return 1.0

        # Context containing sensitive information may increase bias probability
        sensitive_terms = ['low income', 'elderly', 'beginners', 'lack experience', 'poverty']
        if any(term in context.lower() for term in sensitive_terms):
            return 1.4
        elif any(term in context.lower() for term in ['high income', 'experts', 'rich experience']):
            return 1.2
        else:
            return 1.0

    def detect_investment_bias(self, generated_texts: List[str],
                               investor_profiles: List[Dict]) -> Dict[str, Any]:
        """
        Detect bias in investment advice

        Args:
            generated_texts: Model-generated texts
            investor_profiles: Corresponding investor profiles

        Returns:
            Bias detection results
        """
        self.logger.info(f"Detecting bias in {len(generated_texts)} investment advice texts")

        bias_results = {}

        for i, (text, profile) in enumerate(zip(generated_texts, investor_profiles)):
            aul_result = self.calculate_aul_scores([text])

            if text in aul_result:
                text_result = aul_result[text]

                # Analyze specific types of bias
                specific_biases = self._analyze_specific_biases(text, profile, text_result['aul_score'])

                bias_results[f"sample_{i}"] = {
                    'text': text,
                    'profile': profile,
                    'aul_score': text_result['aul_score'],
                    'bias_probability': text_result['bias_probability'],
                    'specific_biases': specific_biases,
                    'overall_bias_level': self._calculate_overall_bias_level(text_result, specific_biases),
                    'recommendation': self._generate_debiasing_recommendation(specific_biases)
                }

        return bias_results

    def _analyze_specific_biases(self, text: str, profile: Dict, aul_score: float) -> Dict[str, float]:
        """Analyze specific types of bias"""
        biases = {}

        # Group bias analysis
        group_terms = {
            'young': ['young people', 'youth', 'just started working'],
            'old': ['elderly', 'retired', 'senior'],
            'rich': ['high net worth', 'wealthy', 'rich'],
            'poor': ['low income', 'financial difficulty', 'average worker']
        }

        for bias_type, terms in group_terms.items():
            term_count = sum(1 for term in terms if term.lower() in text.lower())
            biases[f'group_{bias_type}'] = min(term_count * 0.3, 1.0)

        # Risk bias analysis
        risk_terms = {
            'conservative': ['conservative', 'safe', 'secure'],
            'aggressive': ['aggressive', 'high risk', 'high return']
        }

        for risk_type, terms in risk_terms.items():
            term_count = sum(1 for term in terms if term.lower() in text.lower())
            biases[f'risk_{risk_type}'] = min(term_count * 0.4, 1.0)

        # Overall bias based on AUL score
        biases['overall_aul_based'] = 1.0 - aul_score

        return biases

    def _calculate_overall_bias_level(self, aul_result: Dict, specific_biases: Dict) -> str:
        """Calculate overall bias level"""
        bias_scores = list(specific_biases.values()) + [aul_result['bias_probability']]
        avg_bias = np.mean(bias_scores)

        if avg_bias > 0.7:
            return "High Bias"
        elif avg_bias > 0.4:
            return "Medium Bias"
        else:
            return "Low Bias"

    def _generate_debiasing_recommendation(self, specific_biases: Dict) -> List[str]:
        """Generate debiasing recommendations"""
        recommendations = []

        for bias_type, score in specific_biases.items():
            if score > 0.5:
                if 'group' in bias_type:
                    recommendations.append("Reduce group stereotypes and provide more personalized advice")
                elif 'risk' in bias_type:
                    recommendations.append("Balance risk descriptions and provide diversified investment options")
                elif 'wealth' in bias_type:
                    recommendations.append("Avoid pre-judgments based on wealth levels")

        if not recommendations:
            recommendations.append("Current advice is relatively fair, continue maintaining this standard")

        return recommendations

    def analyze_bias_trends(self, bias_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze bias trends across multiple samples

        Args:
            bias_results: Results from bias detection

        Returns:
            Bias trend analysis
        """
        self.logger.info("Analyzing bias trends across samples")

        bias_scores = []
        bias_levels = {'High Bias': 0, 'Medium Bias': 0, 'Low Bias': 0}
        specific_bias_counts = {}

        for sample_key, result in bias_results.items():
            bias_scores.append(result['bias_probability'])
            bias_levels[result['overall_bias_level']] += 1

            # Count specific biases
            for bias_type, score in result['specific_biases'].items():
                if score > 0.5:  # Only count significant biases
                    specific_bias_counts[bias_type] = specific_bias_counts.get(bias_type, 0) + 1

        trend_analysis = {
            'total_samples': len(bias_results),
            'average_bias_score': np.mean(bias_scores) if bias_scores else 0,
            'bias_distribution': bias_levels,
            'common_biases': dict(sorted(specific_bias_counts.items(),
                                         key=lambda x: x[1], reverse=True)[:5]),
            'bias_variability': np.std(bias_scores) if bias_scores else 0
        }

        self.logger.info(f"Bias trend analysis completed: {trend_analysis['average_bias_score']:.3f} average bias")
        return trend_analysis

    def export_bias_report(self, bias_results: Dict[str, Any], output_path: str) -> Dict[str, Any]:
        """
        Export comprehensive bias analysis report

        Args:
            bias_results: Bias detection results
            output_path: Path to save the report

        Returns:
            Export status and summary
        """
        import json
        import os

        self.logger.info(f"Exporting bias report to {output_path}")

        # Create comprehensive report
        report = {
            'summary': {
                'total_samples_analyzed': len(bias_results),
                'samples_needing_debiasing': sum(1 for r in bias_results.values()
                                                 if r.get('needs_debiasing', False)),
                'average_bias_probability': np.mean([r['bias_probability']
                                                     for r in bias_results.values()])
            },
            'detailed_analysis': bias_results,
            'bias_trends': self.analyze_bias_trends(bias_results),
            'recommendations': self._generate_overall_recommendations(bias_results)
        }

        # Ensure directory exists
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.',
                    exist_ok=True)

        # Save report
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        export_summary = {
            'report_path': output_path,
            'export_status': 'Success',
            'report_size': len(bias_results),
            'high_priority_issues': sum(1 for r in bias_results.values()
                                        if r['overall_bias_level'] == 'High Bias')
        }

        self.logger.info(f"Bias report exported successfully: {export_summary}")
        return export_summary

    def _generate_overall_recommendations(self, bias_results: Dict[str, Any]) -> List[str]:
        """Generate overall recommendations based on bias analysis"""
        recommendations = []

        # Analyze common patterns
        high_bias_count = sum(1 for r in bias_results.values()
                              if r['overall_bias_level'] == 'High Bias')
        total_count = len(bias_results)

        if high_bias_count / total_count > 0.3:
            recommendations.append("Implement systematic debiasing training for the model")

        # Check for specific bias patterns
        group_bias_count = sum(1 for r in bias_results.values()
                               if any('group_' in bias for bias in r['specific_biases']
                                      and r['specific_biases'][bias] > 0.5))

        if group_bias_count > 0:
            recommendations.append("Address group stereotyping in model responses")

        risk_bias_count = sum(1 for r in bias_results.values()
                              if any('risk_' in bias for bias in r['specific_biases']
                                     and r['specific_biases'][bias] > 0.5))

        if risk_bias_count > 0:
            recommendations.append("Improve risk assessment balance in recommendations")

        if not recommendations:
            recommendations.append("Current model shows good bias control, maintain monitoring")

        return recommendations