"""
Data Sampling Module - Implements Imbalanced Data Sampling
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import euclidean_distances
from typing import Dict, List, Tuple, Any
from utils.logger import setup_logger
from config.settings import Config


class DataSampler:
    """Data Sampler - Implements Improved MWMOTE Algorithm"""

    def __init__(self):
        self.logger = setup_logger("DataSampler")
        self.sampling_config = Config.SAMPLING_CONFIG

    def mwmote_sampling(self,
                        majority_samples: pd.DataFrame,
                        minority_samples: pd.DataFrame,
                        bias_weights: Dict[str, float]) -> pd.DataFrame:
        """
        MWMOTE Sampling Algorithm (Equations 7, 8, 9)

        Args:
            majority_samples: Majority class samples
            minority_samples: Minority class samples
            bias_weights: Bias weights

        Returns:
            Resampled minority class samples
        """
        self.logger.info("Starting MWMOTE imbalanced data sampling")

        if len(minority_samples) == 0:
            self.logger.warning("Minority samples are empty")
            return minority_samples

        if len(majority_samples) == 0:
            self.logger.warning("Majority samples are empty")
            return minority_samples

        # Calculate information weights (Equation 7)
        information_weights = self._calculate_information_weights(
            majority_samples, minority_samples, bias_weights
        )

        # Calculate selection weights and probabilities (Equations 8, 9)
        selection_weights = self._calculate_selection_weights(information_weights)
        selection_probabilities = self._calculate_selection_probabilities(selection_weights)

        # Generate synthetic samples
        synthetic_samples = self._generate_synthetic_samples(
            minority_samples, selection_probabilities
        )

        self.logger.info(f"MWMOTE sampling completed, generated {len(synthetic_samples)} synthetic samples")
        return synthetic_samples

    def _calculate_information_weights(self,
                                       majority_samples: pd.DataFrame,
                                       minority_samples: pd.DataFrame,
                                       bias_weights: Dict[str, float]) -> Dict[Any, float]:
        """Calculate information weights (Equation 7)"""
        information_weights = {}

        numeric_minority = minority_samples.select_dtypes(include=[np.number])
        numeric_majority = majority_samples.select_dtypes(include=[np.number])

        if numeric_minority.empty or numeric_majority.empty:
            self.logger.warning("Numeric data is empty, cannot calculate information weights")
            return {}

        for i, minority_idx in enumerate(minority_samples.index):
            minority_sample = numeric_minority.loc[minority_idx]
            weights = []

            for j, majority_idx in enumerate(majority_samples.index):
                majority_sample = numeric_majority.loc[majority_idx]

                # Calculate closeness factor
                closeness = self._calculate_closeness(minority_sample, majority_sample)

                # Calculate density factor
                density = self._calculate_density(minority_sample, numeric_majority)

                # Combine with bias weight
                bias_key = f"{minority_idx}_{majority_idx}"
                bias_weight = bias_weights.get(bias_key, 1.0)

                # Information weight
                information_weight = closeness * density * bias_weight
                weights.append(information_weight)

            if weights:
                information_weights[minority_idx] = np.mean(weights)

        return information_weights

    def _calculate_closeness(self, sample1: pd.Series, sample2: pd.Series) -> float:
        """Calculate closeness factor"""
        try:
            distance = np.linalg.norm(sample1.values - sample2.values)
            return 1.0 / (1.0 + distance)
        except:
            return 1.0

    def _calculate_density(self, sample: pd.Series, samples: pd.DataFrame) -> float:
        """Calculate density factor"""
        try:
            if len(samples) == 0:
                return 1.0

            distances = []
            for idx, other_sample in samples.iterrows():
                if not other_sample.equals(sample):
                    distance = np.linalg.norm(sample.values - other_sample.values)
                    distances.append(distance)

            if distances:
                avg_distance = np.mean(distances)
                return 1.0 / (1.0 + avg_distance)
            else:
                return 1.0
        except:
            return 1.0

    def _calculate_selection_weights(self, information_weights: Dict[Any, float]) -> Dict[Any, float]:
        """Calculate selection weights (Equation 8)"""
        return information_weights  # Simplified implementation

    def _calculate_selection_probabilities(self, selection_weights: Dict[Any, float]) -> Dict[Any, float]:
        """Calculate selection probabilities (Equation 9)"""
        total_weight = sum(selection_weights.values())
        if total_weight == 0:
            # If all weights are zero, distribute probability uniformly
            n = len(selection_weights)
            return {k: 1.0 / n for k in selection_weights.keys()}

        return {k: v / total_weight for k, v in selection_weights.items()}

    def _generate_synthetic_samples(self,
                                    minority_samples: pd.DataFrame,
                                    selection_probabilities: Dict[Any, float]) -> pd.DataFrame:
        """Generate synthetic samples"""
        if not selection_probabilities:
            return minority_samples

        synthetic_samples = []
        num_synthetic = int(len(minority_samples) * self.sampling_config['synthetic_sample_ratio'])

        # Use K-means clustering
        numeric_data = minority_samples.select_dtypes(include=[np.number])
        if numeric_data.empty:
            return minority_samples

        n_clusters = min(self.sampling_config['num_clusters'], len(numeric_data))
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        clusters = kmeans.fit_predict(numeric_data)

        minority_samples = minority_samples.copy()
        minority_samples['cluster'] = clusters

        for _ in range(num_synthetic):
            # Select sample based on selection probability
            selected_idx = np.random.choice(
                list(selection_probabilities.keys()),
                p=list(selection_probabilities.values())
            )

            selected_sample = minority_samples.loc[selected_idx]
            cluster_label = selected_sample['cluster']

            # Randomly select another sample from the same cluster
            cluster_samples = minority_samples[minority_samples['cluster'] == cluster_label]
            if len(cluster_samples) > 1:
                other_sample = cluster_samples.drop(selected_idx).sample(1).iloc[0]

                # Generate new sample through linear interpolation (Equation 12)
                alpha = np.random.random()
                new_sample = selected_sample * alpha + other_sample * (1 - alpha)
                new_sample['cluster'] = cluster_label  # Maintain cluster label

                synthetic_samples.append(new_sample)

        synthetic_df = pd.DataFrame(synthetic_samples)
        # Remove temporary cluster column
        if 'cluster' in synthetic_df.columns:
            synthetic_df = synthetic_df.drop('cluster', axis=1)

        return synthetic_df