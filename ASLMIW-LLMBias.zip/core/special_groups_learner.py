"""
Special Groups Learning Module
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Callable, Any
from utils.logger import setup_logger


class SpecialGroupsLearner:
    """Special Groups Learner"""

    def __init__(self):
        self.logger = setup_logger("SpecialGroupsLearner")
        self.special_rules = self._initialize_special_rules()

    def _initialize_special_rules(self) -> Dict[str, Dict]:
        """Initialize special group rules"""
        rules = {
            'young_investors': {
                'condition': lambda x: x['age'] < 30,
                'adjustments': {
                    'investment_amount': lambda x: x * 0.8,  # Young investors have lower investment amounts
                    'risk_tolerance': 'medium'  # Medium risk tolerance
                }
            },
            'senior_investors': {
                'condition': lambda x: x['age'] >= 60,
                'adjustments': {
                    'investment_amount': lambda x: x * 1.2,  # Senior investors may have more savings
                    'risk_tolerance': 'low'  # Lower risk tolerance
                }
            },
            'high_net_worth': {
                'condition': lambda x: x.get('total_assets', 0) > 300000,
                'adjustments': {
                    'portfolio_diversity': lambda x: min(x * 1.3, 1.0),
                    # High net worth individuals have more diversified portfolios
                    'investment_experience': lambda x: x + 5  # Assumed to be more experienced
                }
            },
            'low_income': {
                'condition': lambda x: x.get('annual_income', 0) < 50000,
                'adjustments': {
                    'investment_amount': lambda x: x * 0.6,
                    'transaction_frequency': lambda x: max(x - 2, 1)  # Lower transaction frequency
                }
            }
        }
        return rules

    def process_special_groups(self, samples: pd.DataFrame) -> pd.DataFrame:
        """
        Process special groups (Equations 14a, 14b)

        Args:
            samples: Input samples

        Returns:
            Complete dataset with special group processing
        """
        self.logger.info("Starting special groups learning")

        processed_samples = samples.copy()
        special_group_samples = []

        # Identify and process each special group
        for group_name, rule_config in self.special_rules.items():
            group_condition = rule_config['condition']
            adjustments = rule_config['adjustments']

            # Apply condition to filter special group
            group_mask = processed_samples.apply(group_condition, axis=1)
            special_group = processed_samples[group_mask].copy()

            if not special_group.empty:
                self.logger.info(f"Identified {group_name} group, sample count: {len(special_group)}")

                # Apply adjustment rules
                adjusted_group = self._apply_group_adjustments(special_group, adjustments, group_name)
                special_group_samples.append(adjusted_group)

        # Merge all special group samples
        if special_group_samples:
            all_special_samples = pd.concat(special_group_samples, ignore_index=True)

            # Equation 14a: Generate special group samples
            final_special_samples = self._generate_special_samples(all_special_samples)

            # Equation 14b: Merge into complete dataset
            full_dataset = pd.concat([processed_samples, final_special_samples], ignore_index=True)

            self.logger.info(f"Special group processing completed, total samples: {len(full_dataset)}")
            return full_dataset
        else:
            self.logger.info("No special groups identified")
            return processed_samples

    def _apply_group_adjustments(self, group_samples: pd.DataFrame,
                                 adjustments: Dict[str, Any],
                                 group_name: str) -> pd.DataFrame:
        """Apply group-specific adjustments"""
        adjusted_samples = group_samples.copy()

        for feature, adjustment in adjustments.items():
            if feature in adjusted_samples.columns:
                if callable(adjustment):
                    # Apply function adjustment
                    adjusted_samples[feature] = adjusted_samples[feature].apply(adjustment)
                else:
                    # Apply fixed value adjustment
                    adjusted_samples[feature] = adjustment

        # Add group identifier
        adjusted_samples['special_group'] = group_name

        return adjusted_samples

    def _generate_special_samples(self, special_samples: pd.DataFrame) -> pd.DataFrame:
        """Generate special group samples (Equation 14a)"""
        if special_samples.empty:
            return special_samples

        generated_samples = special_samples.copy()

        # Generate additional sample variants for special groups
        num_variants = min(3, len(special_samples))
        variant_samples = []

        for _ in range(num_variants):
            # Create slight variations for each special group sample
            for _, sample in special_samples.iterrows():
                variant = sample.copy()

                # Add random variation to numeric features
                numeric_features = variant.select_dtypes(include=[np.number]).index
                for feature in numeric_features:
                    if feature != 'special_group':
                        variation = np.random.uniform(0.9, 1.1)
                        variant[feature] = variant[feature] * variation

                variant_samples.append(variant)

        if variant_samples:
            variant_df = pd.DataFrame(variant_samples)
            # Remove possible duplicate samples
            variant_df = variant_df.drop_duplicates()
            return variant_df
        else:
            return generated_samples

    def create_custom_special_group(self,
                                    condition: Callable,
                                    adjustments: Dict[str, Any],
                                    group_name: str) -> None:
        """
        Create custom special group

        Args:
            condition: Group condition function
            adjustments: Adjustment rules
            group_name: Group name
        """
        self.special_rules[group_name] = {
            'condition': condition,
            'adjustments': adjustments
        }
        self.logger.info(f"Created custom special group: {group_name}")