"""
辅助函数工具
"""

import numpy as np
import pandas as pd
import torch
from typing import Dict, List, Any, Union

def set_random_seed(seed: int = 42):
    """设置随机种子以保证可重复性"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

def normalize_data(data: pd.DataFrame, features: List[str]) -> pd.DataFrame:
    """数据标准化"""
    normalized_data = data.copy()
    for feature in features:
        if feature in normalized_data.columns:
            if normalized_data[feature].dtype in [np.int64, np.float64]:
                mean = normalized_data[feature].mean()
                std = normalized_data[feature].std()
                if std > 0:
                    normalized_data[feature] = (normalized_data[feature] - mean) / std
    return normalized_data

def calculate_feature_importance(data: pd.DataFrame, target: str) -> Dict[str, float]:
    """计算特征重要性（简化版本）"""
    importance_scores = {}
    
    if target not in data.columns:
        return importance_scores
        
    for column in data.columns:
        if column != target and data[column].dtype in [np.int64, np.float64]:
            # 使用相关系数作为重要性评分
            correlation = abs(data[column].corr(data[target]))
            importance_scores[column] = correlation if not np.isnan(correlation) else 0.0
    
    return importance_scores

def check_data_quality(data: pd.DataFrame) -> Dict[str, Any]:
    """检查数据质量"""
    quality_report = {
        'total_samples': len(data),
        'missing_values': data.isnull().sum().to_dict(),
        'data_types': data.dtypes.to_dict(),
        'numeric_stats': {}
    }
    
    # 数值型数据统计
    numeric_data = data.select_dtypes(include=[np.number])
    for column in numeric_data.columns:
        quality_report['numeric_stats'][column] = {
            'mean': numeric_data[column].mean(),
            'std': numeric_data[column].std(),
            'min': numeric_data[column].min(),
            'max': numeric_data[column].max()
        }
    
    return quality_report