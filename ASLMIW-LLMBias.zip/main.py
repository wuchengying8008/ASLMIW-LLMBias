"""
ASLMIW-LLMBias System Main Program
"""

import pandas as pd
import argparse
import sys
import os

# Add project path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from data.data_processor import InvestorDataProcessor
from core.framework import ASLMIWLLMBiasFramework
from utils.logger import setup_logger
from utils.helpers import set_random_seed


def main():
    """Main function"""
    logger = setup_logger("Main")

    # Parse command line arguments
    parser = argparse.ArgumentParser(description='ASLMIW-LLMBias Framework')
    parser.add_argument('--epochs', type=int, default=5, help='Number of training epochs')
    parser.add_argument('--samples', type=int, default=1000, help='Number of samples')
    parser.add_argument('--mode', choices=['train', 'predict', 'demo'], default='demo', help='Run mode')
    args = parser.parse_args()

    logger.info("Starting ASLMIW-LLMBias System")
    logger.info(f"Run mode: {args.mode}, Samples: {args.samples}, Epochs: {args.epochs}")

    try:
        # Set random seed
        set_random_seed(42)

        # Initialize framework
        framework = ASLMIWLLMBiasFramework()

        if args.mode == 'train' or args.mode == 'demo':
            # Training mode
            logger.info("Starting framework training...")
            pipeline_results = framework.run_complete_pipeline(
                num_samples=args.samples,
                epochs=args.epochs,
                save_path="./debiased_model" if args.mode == 'train' else None
            )

            # Display training results
            print("\n=== Training Results ===")
            print(f"Final Loss: {pipeline_results['final_metrics']['training_performance']['final_loss']:.4f}")
            print(f"Training Epochs: {len(pipeline_results['pipeline_stages']['model_finetuning']['losses'])}")

            # Display bias reduction results
            bias_reduction = pipeline_results['bias_reduction']
            print(f"\nBias Reduction Results:")
            print(f"  Initial Bias Score: {bias_reduction['initial_bias_score']:.4f}")
            print(f"  Final Bias Score: {bias_reduction['final_bias_score']:.4f}")
            print(f"  Reduction: {bias_reduction['percentage_reduction']:.1f}%")
            print(f"  Effectiveness: {bias_reduction['effectiveness']}")

            # Display response quality
            quality_metrics = pipeline_results['final_metrics']['response_quality']
            print(f"\nResponse Quality:")
            print(f"  Average Quality Score: {quality_metrics['avg_quality_score']:.4f}")
            print(f"  High Quality Ratio: {quality_metrics['high_quality_ratio']:.1%}")

        if args.mode == 'predict' or args.mode == 'demo':
            # Prediction mode
            logger.info("Starting prediction...")

            # Create sample investor profiles for prediction
            sample_profiles = [
                {
                    'investor_id': 'TEST_001',
                    'age': 28,
                    'annual_income': 45000,
                    'investment_experience': 2,
                    'risk_tolerance': 'medium',
                    'group_id': 1
                },
                {
                    'investor_id': 'TEST_002',
                    'age': 55,
                    'annual_income': 120000,
                    'investment_experience': 20,
                    'risk_tolerance': 'conservative',
                    'group_id': 2
                },
                {
                    'investor_id': 'TEST_003',
                    'age': 35,
                    'annual_income': 80000,
                    'investment_experience': 8,
                    'risk_tolerance': 'aggressive',
                    'group_id': 3
                }
            ]

            # Generate advice for sample investors
            advice_results = framework.batch_generate_advice(sample_profiles, 'wealth_management')

            print("\n=== Investment Advice Results ===")
            for i, result in enumerate(advice_results['individual_results']):
                if not result.get('error'):
                    print(f"\nInvestor {i + 1}: {result['investor_profile']['investor_id']}")
                    print(f"  Advice: {result['generated_advice']}")
                    print(f"  Quality Score: {result['quality_score']:.2f}")
                    print(f"  Bias Probability: {result['bias_analysis'].get('bias_probability', 'N/A'):.2f}")
                    print(f"  Appropriate: {result['is_appropriate']}")
                else:
                    print(f"\nInvestor {i + 1}: Error - {result['error']}")

            # Display batch analysis
            batch_analysis = advice_results['batch_analysis']
            print(f"\nBatch Analysis:")
            print(f"  Success Rate: {batch_analysis['success_rate']:.1%}")
            print(f"  Average Quality: {batch_analysis['avg_quality_score']:.2f}")
            print(f"  Average Bias: {batch_analysis['avg_bias_score']:.2f}")

        # Display framework status
        framework_status = framework.get_framework_status()
        print("\n=== Framework Status ===")
        for key, value in framework_status.items():
            if key == 'components_status':
                print(f"Components Status:")
                for comp, status in value.items():
                    print(f"  {comp}: {status}")
            else:
                print(f"{key}: {value}")

        logger.info("ASLMIW-LLMBias System execution completed")

    except Exception as e:
        logger.error(f"System execution error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()