"""
ASLMIW-LLMBias Framework Configuration Package
"""

from .settings import Config, PROMPT_TEMPLATES, MODEL_NAME, PRECISION_THRESHOLD, STATIC_FEATURES, DYNAMIC_FEATURES, SAMPLING_CONFIG

# Export all public variables and classes
__all__ = [
    'Config',
    'PROMPT_TEMPLATES',
    'MODEL_NAME',
    'PRECISION_THRESHOLD',
    'STATIC_FEATURES',
    'DYNAMIC_FEATURES',
    'SAMPLING_CONFIG'
]

# Version information
__version__ = '1.0.0'
__author__ = 'ASLMIW-LLMBias Framework Team'