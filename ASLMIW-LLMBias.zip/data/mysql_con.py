import pymysql
import pandas as pd


def query_mysql_data():
    try:
        connection = pymysql.connect(
            host='192.168.3.456',
            user='test',
            password='test@123',
            database='cust',
            port=3306,
            charset='utf8mb4'
        )
        with connection.cursor() as cursor:
            # 3. 编写SQL查询语句
            sql_query = "SELECT * FROM custs WHERE id_no  is not null and %s"

            # 4. 执行SQL查询
            cursor.execute(sql_query, ('condition_value',))
            results = cursor.fetchall()

    except pymysql.Error as e:
        print(f"load data faillure: {e}")

    finally:

        if connection:
            connection.close()
            print("数据库连接已关闭")


# 另一种使用上下文管理器的方式
def query_with_context(sql_text):
    try:
        with pymysql.connect(
                host='192.168.3.455',
                user='test',
                password='test2@123',
                database='cust',
                port=3306,
                charset='utf8mb4'
        ) as connection:

            with connection.cursor() as cursor:
                # 查询示例
                cursor.execute(sql_text)

                # 获取列名
                columns = [desc[0] for desc in cursor.description]
                print("columns:", columns)

                # 获取数据
                data = cursor.fetchall()

                # 转换为DataFrame
                df = pd.DataFrame(data, columns=columns)
                print(df)

    except Exception as e:
        print(f"error: {e}")


if __name__ == "__main__":
    query_mysql_data()

