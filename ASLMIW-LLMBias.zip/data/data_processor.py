"""
Data Processing Module - Specialized for investor data and bias annotation
"""

import pandas as pd
import numpy as np
import json
from typing import Dict, List, Tuple, Any
from transformers import AutoTokenizer

from data.mysql_con import query_with_context
from utils.logger import setup_logger
from config.settings import Config, PROMPT_TEMPLATES


class InvestorDataProcessor:
    """Investor Data Processor"""

    def __init__(self, model_name: str = Config.MODEL_NAME):
        self.logger = setup_logger("InvestorDataProcessor")
        try:
         self.tokenizer = AutoTokenizer.from_pretrained(model_name)
         self.tokenizer.pad_token = self.tokenizer.eos_token
        except Exception as e:
            self.logger.error(f"can not find the model: {Config.MODEL_NAME} ")


    def generate_training_data(self, num_samples: int = 1000) -> Dict[str, Any]:
        """
        Generate training data with bias annotations

        Args:
            num_samples: Number of samples

        Returns:
            Training data dictionary
        """
        self.logger.info(f"Generating {num_samples} training samples")

        data = {
            'texts': [],
            'labels': [],
            'investor_profiles': [],
            'bias_annotations': [],
            'financial_scenarios': []
        }

        scenarios = list(Config.FINANCIAL_SCENARIOS.keys())
        bias_types = list(Config.BIAS_TYPES.keys())

        for i in range(num_samples):
            # Generate investor profile
            profile = self._generate_investor_profile(i)

            # Generate financial scenario and prompt
            scenario = np.random.choice(scenarios)
            prompt, context = self._generate_prompt(profile, scenario)

            # Generate bias annotation
            bias_annotation = self._generate_bias_annotation(profile, scenario)

            # Generate target response (should be unbiased)
            target_response = self._generate_target_response(profile, scenario, context)

            data['texts'].append(prompt)
            data['labels'].append(target_response)
            data['investor_profiles'].append(profile)
            data['bias_annotations'].append(bias_annotation)
            data['financial_scenarios'].append(scenario)

        self.logger.info(f"Training data generation completed, total samples: {len(data['texts'])}")
        return data

    def _generate_investor_profile(self, investor_id: int) -> Dict[str, Any]:
        """Get investor profile from database"""
        df = query_with_context("select * from custs where id_no is not null and custname is not null")

        if df.empty:
            self.logger.warning("No investor data found in database")
            return {}


        for row in df.itertuples():
            try:

                age = getattr(row, 'age', 35)  # 提供默认值
                income = getattr(row, 'income', 50000)
                assets = getattr(row, 'total_assets', 100000)
                experience = getattr(row, 'investment_experience', 5)

                # 根据特征分配投资者群体
                if age < 30:
                    group_id = 1  # 年轻投资者
                elif income > 200000:
                    group_id = 4  # 高净值投资者
                elif experience > 15:
                    group_id = 3  # 经验丰富投资者
                else:
                    group_id = 2  # 普通投资者

                risk_tolerance = Config.INVESTOR_GROUPS[group_id]['risk_profile']

                investor_profile = {
                    'investor_id': f'INV_{investor_id:04d}',
                    'age': age,
                    'annual_income': income,
                    'total_assets': assets,
                    'investment_experience': experience,
                    'risk_tolerance': risk_tolerance,
                    'group_id': group_id,
                    'group_name': Config.INVESTOR_GROUPS[group_id]['name']
                }

                self.logger.info(f"Generated profile for investor {investor_id}: {investor_profile}")
                return investor_profile

            except Exception as e:
                self.logger.error(f"Error processing row {row.Index}: {e}")
                continue


        self.logger.warning("No valid investor data found, returning default profile")
        return self._get_default_investor_profile(investor_id)

    def _get_default_investor_profile(self, investor_id: int) -> Dict[str, Any]:
        """get default investor """
        return {
            'investor_id': f'INV_{investor_id:04d}',
            'age': 35,
            'annual_income': 50000,
            'total_assets': 100000,
            'investment_experience': 5,
            'risk_tolerance': 'medium',
            'group_id': 2,
            'group_name': 'Balanced Investor'
        }

    def _generate_prompt(self, profile: Dict, scenario: str) -> Tuple[str, str]:
        """Generate prompt and context"""
        context = f"Investor age {profile['age']}, annual income {profile['annual_income']}, investment experience {profile['investment_experience']} years, risk tolerance {profile['risk_tolerance']}."

        if scenario == 'wealth_management':
            prompt = f"{context} Please provide wealth management advice for this {profile['group_name']}."
        elif scenario == 'risk_assessment':
            prompt = f"{context} Please assess this investor's risk tolerance and provide investment recommendations."
        elif scenario == 'portfolio_optimization':
            prompt = f"{context} Please optimize the investment portfolio allocation for this investor."
        else:
            prompt = f"{context} Please provide professional financial service advice for this investor."

        return prompt, context

    def _generate_bias_annotation(self, profile: Dict, scenario: str) -> Dict[str, Any]:
        """Generate bias annotation"""
        bias_scores = {}

        # Calculate various bias scores
        bias_scores['group_bias'] = self._calculate_group_bias(profile)
        bias_scores['risk_bias'] = self._calculate_risk_bias(profile)
        bias_scores['wealth_bias'] = self._calculate_wealth_bias(profile)
        bias_scores['experience_bias'] = self._calculate_experience_bias(profile)

        # Overall bias score
        overall_bias = np.mean(list(bias_scores.values()))

        return {
            'bias_scores': bias_scores,
            'overall_bias': overall_bias,
            'needs_debiasing': overall_bias > 0.3,  # Bias threshold
            'bias_types': [bias_type for bias_type, score in bias_scores.items() if score > 0.3]
        }

    def _calculate_group_bias(self, profile: Dict) -> float:
        """Calculate group bias score"""
        # Special groups (group 5) are more prone to bias
        if profile['group_id'] == 5:
            return 0.8
        elif profile['group_id'] in [1, 4]:  # Conservative and professional investors
            return 0.4
        else:
            return 0.2

    def _calculate_risk_bias(self, profile: Dict) -> float:
        """Calculate risk bias score"""
        risk_mapping = {'low': 0.6, 'medium': 0.3, 'high': 0.4, 'very_high': 0.7}
        return risk_mapping.get(profile['risk_tolerance'], 0.3)

    def _calculate_wealth_bias(self, profile: Dict) -> float:
        """Calculate wealth bias score"""
        if profile['annual_income'] < 50000:
            return 0.7  # Low income bias
        elif profile['annual_income'] > 200000:
            return 0.5  # High income bias
        else:
            return 0.2

    def _calculate_experience_bias(self, profile: Dict) -> float:
        """Calculate experience bias score"""
        if profile['investment_experience'] < 3:
            return 0.6  # Novice bias
        elif profile['investment_experience'] > 20:
            return 0.4  # Expert bias
        else:
            return 0.2

    def _generate_target_response(self, profile: Dict, scenario: str, context: str) -> str:
        """Generate unbiased target response"""
        base_responses = {
            'wealth_management': "Based on your personal situation, I recommend a diversified investment strategy to balance risk and return.",
            'risk_assessment': "Considering your risk tolerance and investment goals, I suggest choosing investment products that match your risk preference.",
            'portfolio_optimization': "I recommend an asset allocation strategy that dynamically adjusts the investment portfolio based on market conditions."
        }

        base_response = base_responses.get(scenario,
                                           "I will provide personalized investment advice based on your specific situation.")

        # Add group-specific suggestions (unbiased version)
        if profile['group_id'] == 1:
            addition = "Considering your investment preferences, I suggest focusing on stable investment products."
        elif profile['group_id'] == 4:
            addition = "Based on your investment experience, you may consider more complex investment strategies."
        else:
            addition = "I recommend regularly reviewing your investment portfolio to ensure alignment with your financial goals."

        return f"{base_response} {addition} We will ensure the fairness and appropriateness of our recommendations."

    def prepare_finetuning_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Prepare data format for fine-tuning

        Args:
            data: Raw data

        Returns:
            Data format suitable for model fine-tuning
        """
        self.logger.info("Preparing fine-tuning data format")

        finetuning_data = {
            'input_ids': [],
            'attention_mask': [],
            'labels': [],
            'bias_scores': [],
            'metadata': []
        }

        for i, (text, label, profile, bias_annotation, scenario) in enumerate(zip(
                data['texts'], data['labels'], data['investor_profiles'],
                data['bias_annotations'], data['financial_scenarios']
        )):
            # Encode input text
            inputs = self.tokenizer(
                text,
                truncation=True,
                padding='max_length',
                max_length=Config.MAX_SEQUENCE_LENGTH,
                return_tensors='pt'
            )

            # Encode target response
            targets = self.tokenizer(
                label,
                truncation=True,
                padding='max_length',
                max_length=Config.MAX_SEQUENCE_LENGTH,
                return_tensors='pt'
            )

            finetuning_data['input_ids'].append(inputs['input_ids'].squeeze())
            finetuning_data['attention_mask'].append(inputs['attention_mask'].squeeze())
            finetuning_data['labels'].append(targets['input_ids'].squeeze())
            finetuning_data['bias_scores'].append(bias_annotation['overall_bias'])

            finetuning_data['metadata'].append({
                'investor_profile': profile,
                'scenario': scenario,
                'bias_annotation': bias_annotation
            })

        self.logger.info(f"Fine-tuning data preparation completed, total samples: {len(finetuning_data['input_ids'])}")
        return finetuning_data